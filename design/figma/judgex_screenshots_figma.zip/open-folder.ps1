# Opens the design/figma/from-screenshots folder in Explorer
Start-Process -FilePath (Join-Path $PSScriptRoot "..
\from-screenshots")
# Or use 'ii' for current path
ii "$PSScriptRoot\from-screenshots"